# All-Chain DEX → Telegram Alert Bot

A small Node.js bot that polls GeckoTerminal's new-pools feed and sends Telegram alerts for newly discovered DEX pools that pass configurable liquidity, 5-minute volume, and age filters.

## What it does

- Monitors GeckoTerminal's aggregate new-pools feed, or selected networks.
- Filters by:
  - minimum liquidity
  - minimum 5-minute volume
  - maximum pool age
- Deduplicates pool alerts in memory.
- Sends HTML-formatted Telegram messages.
- Includes GeckoTerminal and explorer links when a known explorer mapping exists.

This is a **new-pair detector**, not a guarantee that a token is safe, legitimate, or tradeable without restrictions.

## Requirements

- Node.js 20+
- A Telegram bot token from @BotFather
- A Telegram chat/channel ID
- Internet-accessible runtime (local PC, VPS, Railway, Render, etc.)

Telegram's Bot API is HTTPS-based and supports `sendMessage`.

## 1. Create Telegram bot

Open @BotFather in Telegram and run:

/newbot

Save the token.

Open your new bot and send `/start`.

If using a group, add the bot to the group. If using a channel, add the bot as an administrator.

## 2. Find CHAT_ID

After sending `/start`, open:

https://api.telegram.org/botYOUR_BOT_TOKEN/getUpdates

Find:

result[].message.chat.id

For a channel you can also use the channel username as the chat_id, e.g. @mychannel, provided the bot has permission to post.

## 3. Configure

Copy:

.env.example -> .env

Fill:

TELEGRAM_BOT_TOKEN=...
TELEGRAM_CHAT_ID=...

Suggested starting filters:

MIN_LIQUIDITY_USD=10000
MIN_VOLUME_5M_USD=2000
MAX_PAIR_AGE_MINUTES=5
POLL_INTERVAL_MS=20000

## 4. Run

npm install
npm start

## 5. Select specific networks (optional)

Leave NETWORKS blank to use the aggregate GeckoTerminal new-pools feed.

Or set, for example:

NETWORKS=eth,bsc,base,arbitrum,polygon_pos,solana

Network IDs vary by GeckoTerminal's supported-network catalog. Use the aggregate feed if you do not want to maintain this list.

## 6. Tuning

Lower liquidity:
MIN_LIQUIDITY_USD=5000

Higher liquidity:
MIN_LIQUIDITY_USD=25000

Lower volume:
MIN_VOLUME_5M_USD=500

More recent only:
MAX_PAIR_AGE_MINUTES=2

## 7. Deployment

### Railway
Create a Node service, upload this folder, set the environment variables, and run:

npm start

### Render
Create a background worker and set:

Build command:
npm install

Start command:
npm start

### VPS
Install Node.js 20+, copy the project, then use:

npm install
npm start

For a production VPS, run it under systemd, PM2, Docker, or another process supervisor.

## Notes on coverage and latency

"All-chain" here means all networks available in GeckoTerminal's new-pools feed, not literally every blockchain in existence.

The public GeckoTerminal API is rate-limited. This project defaults to one aggregate request every 20 seconds (3 requests/minute), which leaves room for retries and avoids aggressive polling.

New-pool discovery is provider/indexer dependent, so it is not guaranteed to catch every pool at the exact block/second it is created.

For very low-latency or guaranteed on-chain coverage, replace the polling source with chain-specific websocket/RPC/indexer streams.

## Safety

The bot does not buy or sell anything and contains no wallet private keys.

Do not put seed phrases/private keys in `.env`.

A new pool can still be a honeypot, malicious token, thin/unstable liquidity, or otherwise unsafe. Treat alerts as discovery signals and independently verify contracts and trading conditions.
